from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import uuid

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key-change-in-prod'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///forum.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    avatar_path = db.Column(db.String(256), nullable=True)
    posts = db.relationship('Post', backref='author', lazy=True)
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy=True)
    received_messages = db.relationship('Message', foreign_keys='Message.recipient_id', backref='recipient', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.now())
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


@app.route('/')
def index():
    return redirect(url_for('wall'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('wall'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        if not username or not email or not password:
            flash('Заполните все поля', 'error')
            return render_template('register.html')
        if User.query.filter_by(username=username).first():
            flash('Имя уже занято', 'error')
            return render_template('register.html')
        if User.query.filter_by(email=email).first():
            flash('Email уже занят', 'error')
            return render_template('register.html')
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash('Регистрация успешна! Теперь войдите.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('wall'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash('Вход успешен!', 'success')
            return redirect(request.args.get('next') or url_for('wall'))
        flash('Неверное имя или пароль', 'error')
    return render_template('login.html')


@app.route('/logout')
def logout():
    logout_user()
    flash('Вы вышли.', 'info')
    return redirect(url_for('wall'))


@app.route('/wall', methods=['GET', 'POST'])
@login_required
def wall():
    if request.method == 'POST':
        text = request.form.get('text', '').strip()
        if text:
            post = Post(text=text, user_id=current_user.id)
            db.session.add(post)
            db.session.commit()
            flash('Сообщение опубликовано!', 'success')
    posts = Post.query.order_by(Post.created_at.desc()).all()
    return render_template('wall.html', posts=posts)


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':
        avatar_file = request.files.get('avatar')
        if avatar_file and avatar_file.filename:
            ext = os.path.splitext(avatar_file.filename)[1].lower()
            if ext not in ('.png', '.jpg', '.jpeg', '.gif', '.webp'):
                flash('Недопустимый формат файла', 'error')
                return redirect(url_for('profile'))
            filename = f"{uuid.uuid4().hex}{ext}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            avatar_file.save(filepath)
            current_user.avatar_path = f"/uploads/{filename}"
            db.session.commit()
            flash('Аватар обновлён!', 'success')
    return render_template('profile.html')


@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return app.send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/messages', methods=['GET', 'POST'])
@login_required
def messages():
    if request.method == 'POST':
        to_username = request.form.get('to', '').strip()
        text = request.form.get('text', '').strip()
        if to_username and text:
            recipient = User.query.filter_by(username=to_username).first()
            if recipient:
                msg = Message(text=text, sender_id=current_user.id, recipient_id=recipient.id)
                db.session.add(msg)
                db.session.commit()
                flash('Сообщение отправлено!', 'success')
            else:
                flash('Пользователь не найден', 'error')
    sent = Message.query.filter_by(sender_id=current_user.id).order_by(Message.created_at.desc()).all()
    received = Message.query.filter_by(recipient_id=current_user.id).order_by(Message.created_at.desc()).all()
    users = User.query.filter(User.id != current_user.id).all()
    return render_template('messages.html', sent=sent, received=received, users=users)


with app.app_context():
    db.create_all()


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
