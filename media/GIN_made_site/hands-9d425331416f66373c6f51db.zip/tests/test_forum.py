import pytest
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, db, User, Post, Message


@pytest.fixture(scope="function")
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['SECRET_KEY'] = 'test-secret'
    with app.app_context():
        db.create_all()
        yield app.test_client()
        db.session.remove()
        db.drop_all()


@pytest.fixture
def user_a(client):
    client.post('/register', data={'username': 'alice', 'password': 'pass123', 'email': 'alice@test.com'})
    client.post('/login', data={'username': 'alice', 'password': 'pass123'})
    return 'alice'


@pytest.fixture
def user_b(client):
    client.post('/register', data={'username': 'bob', 'password': 'pass456', 'email': 'bob@test.com'})
    client.post('/login', data={'username': 'bob', 'password': 'pass456'})
    return 'bob'


@pytest.fixture
def avatar_file(tmp_path):
    f = tmp_path / 'test_avatar.png'
    f.write_bytes(b'fakepngdata')
    return f


def test_registration_creates_user(client):
    """Регистрация создаёт пользователя в БД."""
    r = client.post('/register', data={'username': 'newuser', 'password': 'pw123', 'email': 'new@test.com'})
    assert r.status_code in (200, 302)
    # After registration, user should be redirected to login
    assert r.status_code == 302
    assert 'login' in r.headers.get('Location', '')


def test_registration_duplicate_username(client):
    """Регистрация с дублирующимся username не создаёт пользователя."""
    client.post('/register', data={'username': 'dup', 'password': 'pw1', 'email': 'd1@test.com'})
    client.post('/register', data={'username': 'dup', 'password': 'pw2', 'email': 'd2@test.com'})
    # Second registration should show error, not create user
    r = client.post('/register', data={'username': 'dup', 'password': 'pw2', 'email': 'd2@test.com'})
    assert r.status_code == 200
    html = r.data.decode()
    assert 'Имя уже занято' in html


def test_login_success(client):
    """Успешный логин."""
    client.post('/register', data={'username': 'loginuser', 'password': 'pw123', 'email': 'lu@test.com'})
    r = client.post('/login', data={'username': 'loginuser', 'password': 'pw123'})
    assert r.status_code == 302
    assert 'wall' in r.headers.get('Location', '')


def test_login_wrong_password(client):
    """Неверный пароль не даёт войти."""
    client.post('/register', data={'username': 'wp', 'password': 'correct', 'email': 'wp@test.com'})
    r = client.post('/login', data={'username': 'wp', 'password': 'wrong'})
    assert r.status_code == 200
    html = r.data.decode()
    assert 'Неверное имя или пароль' in html


def test_wall_post_visible(client):
    """Пользователь может создать пост на стене, пост виден."""
    client.post('/register', data={'username': 'walluser', 'password': 'pw1', 'email': 'w@test.com'})
    client.post('/login', data={'username': 'walluser', 'password': 'pw1'})
    r = client.post('/wall', data={'text': 'hello world'})
    assert r.status_code in (200, 302)
    r2 = client.get('/wall')
    assert 'hello world' in r2.data.decode()


def test_wall_requires_auth(client):
    """Стена доступна только авторизованным."""
    r = client.get('/wall')
    # Should redirect to login
    assert r.status_code == 302
    assert 'login' in r.headers.get('Location', '')


def test_avatar_upload(client, avatar_file):
    """Загрузка аватарки."""
    client.post('/register', data={'username': 'avataruser', 'password': 'pw1', 'email': 'av@test.com'})
    client.post('/login', data={'username': 'avataruser', 'password': 'pw1'})
    r = client.post('/profile', data={'avatar': open(avatar_file, 'rb')})
    assert r.status_code == 200
    html = r.data.decode()
    assert '/uploads/' in html


def test_avatar_invalid_format(client):
    """Загрузка файла с недопустимым форматом."""
    client.post('/register', data={'username': 'badav', 'password': 'pw1', 'email': 'ba@test.com'})
    client.post('/login', data={'username': 'badav', 'password': 'pw1'})
    r = client.post('/profile', data={'avatar': open('/dev/null', 'rb')})
    # Should not crash, should show error or redirect
    assert r.status_code in (200, 302)


def test_message_between_users(client):
    """Пользователь A отправляет сообщение пользователю B, B видит его."""
    client.post('/register', data={'username': 'sender', 'password': 'pw1', 'email': 's@test.com'})
    client.post('/register', data={'username': 'receiver', 'password': 'pw2', 'email': 'r@test.com'})
    client.post('/login', data={'username': 'sender', 'password': 'pw1'})
    r = client.post('/messages', data={'to': 'receiver', 'text': 'hello bob'})
    assert r.status_code in (200, 302)
    # Logout and login as receiver
    client.post('/logout')
    client.post('/login', data={'username': 'receiver', 'password': 'pw2'})
    r2 = client.get('/messages')
    assert 'hello bob' in r2.data.decode()


def test_message_to_nonexistent_user(client):
    """Сообщение несуществующему пользователю не создаёт запись."""
    client.post('/register', data={'username': 'msguser', 'password': 'pw1', 'email': 'm@test.com'})
    client.post('/login', data={'username': 'msguser', 'password': 'pw1'})
    r = client.post('/messages', data={'to': 'ghost', 'text': 'hi ghost'})
    assert r.status_code in (200, 302)
    html = r.data.decode()
    assert 'Пользователь не найден' in html


def test_logout(client):
    """Логот выходит из системы."""
    client.post('/register', data={'username': 'logoutuser', 'password': 'pw1', 'email': 'lo@test.com'})
    client.post('/login', data={'username': 'logoutuser', 'password': 'pw1'})
    r = client.get('/logout')
    assert r.status_code == 302
    # After logout, /wall should redirect to login
    r2 = client.get('/wall')
    assert r2.status_code == 302
    assert 'login' in r2.headers.get('Location', '')


def test_password_stored_hashed(client):
    """Пароль хранится в хэше, а не в открытом виде."""
    client.post('/register', data={'username': 'hashuser', 'password': 'secret123', 'email': 'h@test.com'})
    with app.app_context():
        user = User.query.filter_by(username='hashuser').first()
        assert user.password_hash != 'secret123'
        assert user.password_hash.startswith('scrypt:') or user.password_hash.startswith('$pbkdf2$') or user.password_hash.startswith('$werkzeug$')


def test_wall_multiple_posts(client):
    """На стене отображаются все посты."""
    client.post('/register', data={'username': 'multi', 'password': 'pw1', 'email': 'mu@test.com'})
    client.post('/login', data={'username': 'multi', 'password': 'pw1'})
    client.post('/wall', data={'text': 'first post'})
    client.post('/wall', data={'text': 'second post'})
    r = client.get('/wall')
    html = r.data.decode()
    assert 'first post' in html
    assert 'second post' in html


def test_profile_page(client):
    """Страница профиля доступна авторизованному."""
    client.post('/register', data={'username': 'profileuser', 'password': 'pw1', 'email': 'p@test.com'})
    client.post('/login', data={'username': 'profileuser', 'password': 'pw1'})
    r = client.get('/profile')
    assert r.status_code == 200
    html = r.data.decode()
    assert 'Профиль' in html


def test_messages_page_requires_auth(client):
    """Страница сообщений доступна только авторизованным."""
    r = client.get('/messages')
    assert r.status_code == 302
    assert 'login' in r.headers.get('Location', '')


def test_wall_post_author_displayed(client):
    """На стене отображается автор поста."""
    client.post('/register', data={'username': 'author', 'password': 'pw1', 'email': 'au@test.com'})
    client.post('/login', data={'username': 'author', 'password': 'pw1'})
    client.post('/wall', data={'text': 'my post'})
    r = client.get('/wall')
    html = r.data.decode()
    assert 'author' in html
    assert 'my post' in html
